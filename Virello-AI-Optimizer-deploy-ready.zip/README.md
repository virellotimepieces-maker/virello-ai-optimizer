# Virello AI Optimizer

Production-oriented Shopify app scaffold for a commercial AI Store Builder + AI Store Optimizer.

## Product flow

1. Merchant installs the app in Shopify.
2. Shopify authenticates the merchant.
3. Virello scans store data available through granted scopes.
4. Virello generates conversion-focused recommendations.
5. Merchant reviews a Before/After preview.
6. Merchant explicitly approves changes.
7. Virello applies approved changes directly through Shopify APIs.
8. Commercial billing can be enabled for the public app.

## Current build

This package contains the Shopify CLI-oriented app structure and the first dashboard/API contracts.

### Important
The package is not installable until the Shopify app is registered and deployed with:
- a real Shopify Client ID
- a production HTTPS application URL
- a secure Shopify API secret stored as an environment variable
- persistent session storage
- an AI provider/API key

Do not put secrets in source files.

## Current development target

Store: virellotimepieces.com
Shopify domain: gfd1cp-1y.myshopify.com

The store domain is a development target only. The app itself is designed to be installable by other Shopify merchants later.
