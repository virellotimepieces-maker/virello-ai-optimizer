import { authenticate } from "../shopify.server";

export async function action({ request }: { request: Request }) {
  const { admin } = await authenticate.admin(request);
  const body = await request.json();

  // Only approved changes should reach this endpoint.
  // Actual mutations are added per supported Shopify resource after preview.
  return Response.json({
    ok: true,
    applied: Array.isArray(body.changes) ? body.changes.length : 0
  });
}
