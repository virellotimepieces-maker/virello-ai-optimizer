export async function action({ request }: { request: Request }) {
  const body = await request.json();

  // AI provider integration belongs here. Keep the API key server-side.
  return Response.json({
    store: body.store ?? "",
    recommendations: [
      { area: "Homepage", priority: "high", change: "Strengthen the value proposition and primary CTA." },
      { area: "Product pages", priority: "high", change: "Rewrite benefits and reduce purchase friction." },
      { area: "Trust", priority: "medium", change: "Make shipping, returns and guarantees more visible." }
    ]
  });
}
