import { useState } from "react";

const cards = [
  ["AI Store Builder", "Build conversion-focused storefront sections from your brand and offer."],
  ["AI Store Optimizer", "Find weak conversion points across your existing Shopify store."],
  ["Product Page Optimizer", "Improve titles, benefits, CTAs, FAQs, trust and SEO content."],
];

export default function Dashboard() {
  const [store, setStore] = useState("virellotimepieces.com");
  const [status, setStatus] = useState("Ready to scan");

  function generate() {
    setStatus("Generating optimization plan…");
    setTimeout(() => setStatus("Optimization plan ready for preview"), 700);
  }

  return (
    <main style={{fontFamily:"system-ui", maxWidth:1100, margin:"0 auto", padding:32}}>
      <div style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
        <div>
          <div style={{fontSize:14, fontWeight:700, letterSpacing:1}}>VIRELLO</div>
          <h1 style={{margin:"6px 0"}}>Virello AI Optimizer</h1>
          <p style={{color:"#666"}}>Build and optimize Shopify stores for higher conversion potential.</p>
        </div>
        <div style={{padding:"8px 12px", borderRadius:20, background:"#eef7ee"}}>Connected</div>
      </div>

      <section style={{marginTop:28, padding:24, border:"1px solid #ddd", borderRadius:16}}>
        <label style={{display:"block", fontWeight:700}}>Store URL</label>
        <input
          value={store}
          onChange={(e) => setStore(e.target.value)}
          style={{width:"100%", boxSizing:"border-box", marginTop:8, padding:14, border:"1px solid #ccc", borderRadius:10}}
        />
        <button
          onClick={generate}
          style={{marginTop:14, padding:"12px 18px", border:0, borderRadius:10, cursor:"pointer"}}
        >
          Generate High-Converting Plan
        </button>
        <p style={{marginBottom:0, color:"#666"}}>{status}</p>
      </section>

      <section style={{display:"grid", gridTemplateColumns:"repeat(3, 1fr)", gap:16, marginTop:20}}>
        {cards.map(([title, text]) => (
          <article key={title} style={{padding:20, border:"1px solid #ddd", borderRadius:16}}>
            <h2 style={{fontSize:18}}>{title}</h2>
            <p style={{color:"#666"}}>{text}</p>
          </article>
        ))}
      </section>

      <section style={{marginTop:20, padding:24, border:"1px solid #ddd", borderRadius:16}}>
        <h2>Before → After Preview</h2>
        <p style={{color:"#666"}}>
          Approved changes will be sent to Shopify through authenticated Admin API calls.
          The merchant must approve changes before they are applied.
        </p>
      </section>
    </main>
  );
}
