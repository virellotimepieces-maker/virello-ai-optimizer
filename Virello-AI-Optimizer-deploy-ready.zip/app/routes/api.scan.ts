import { authenticate } from "../shopify.server";

export async function action({ request }: { request: Request }) {
  const { admin } = await authenticate.admin(request);

  const response = await admin.graphql(`#graphql
    query VirelloStoreScan {
      shop { name primaryDomain { url } }
      products(first: 20) {
        nodes { id title handle status }
      }
    }
  `);

  return Response.json(await response.json());
}
