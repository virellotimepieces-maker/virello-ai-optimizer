// Virello AI Optimizer - Shopify server configuration.
// Complete authentication/session storage is finalized when the app is
// scaffolded/deployed through the current Shopify CLI template.

import { ApiVersion, shopifyApp } from "@shopify/shopify-app-react-router/server";

const shopify = shopifyApp({
  apiKey: process.env.SHOPIFY_API_KEY || "",
  apiSecretKey: process.env.SHOPIFY_API_SECRET || "",
  appUrl: process.env.SHOPIFY_APP_URL || "",
  apiVersion: ApiVersion.April26,
  future: {},
});

export default shopify;
export const authenticate = shopify.authenticate;
