# Virello AI Optimizer — Deployment Notes

Required environment variables:
- APP_URL=https://YOUR-LIVE-DOMAIN
- SHOPIFY_API_KEY=your Shopify app client ID
- SHOPIFY_API_SECRET=your Shopify app secret
- SCOPES=read_products,write_products,read_product_listings
- SHOPIFY_API_VERSION=2026-07

Do not commit secrets to the repository.

Shopify Dev Dashboard:
1. Set App URL to APP_URL.
2. Keep "Embed app in Shopify admin" enabled.
3. Set the OAuth redirect URL(s) to the callback route implemented by the app.
4. Configure API scopes to match the app's actual routes before release.

Important:
This package is deployment-ready in structure, but it still requires a real hosting URL and Shopify credentials/environment variables. The Shopify Dev Dashboard does not host the application code itself.
