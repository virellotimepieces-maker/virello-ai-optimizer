# Virello AI Optimizer — Build Status

## Completed in this package
- Virello branding
- Shopify CLI-oriented app configuration
- Embedded app layout
- Initial dashboard UI
- Store scan API contract
- AI generation API contract
- Apply/approval API contract
- Conversion-focused product scope

## Next implementation
- Complete Shopify CLI scaffold/session persistence
- Real Admin API mutations for supported resources
- AI provider integration
- Theme/storefront editing strategy
- Before/After diff engine
- Merchant approval flow
- Error recovery and audit log
- Production deployment
- Shopify App Store distribution and billing

## Safety rule
Never apply AI-generated changes without an explicit merchant approval step.
